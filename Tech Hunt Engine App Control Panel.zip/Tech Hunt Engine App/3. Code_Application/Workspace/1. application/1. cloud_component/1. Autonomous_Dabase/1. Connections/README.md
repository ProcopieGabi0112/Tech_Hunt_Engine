# Tech Platform

## _Business Needs_
#### This is an app that will help you to find an it job in no time. Here you will receive an report where you can find a list of jobs that can fit you.

## *Platform Arhitecture*
#### This application will be split in two environment. First environment will be local and the second will be in oracle cloud.
 
### `First Component`
(_student input_)
### Introduction.

In this component i want to create an app where students can enter their studies,knowledge and needs for a job.

### Technology

#### As technologies i want to use: 
#### `Docker` - all component under one roof.
#### `Java & Spring Boot` - for backend.
#### `Javascript & React` - for frontend.
#### `MongoDb` - student cv as json.
#### `PostgresDb` - processing jsons.
#### `Cronjob` - sql jobs programming
#### `Python ETL Scripting` - jobs creations
#### `RabbitMQ` - jsons manip.
#### `MongoDb Change Streams` - json manip.

 
### `Second Component`
(_cloud computing_)
### Introduction.

In this component i want to copy the data from local and i want to create an environment where i can process all the data an create an report where where the student can see a list of recommended jobs and other stuff can help him to be hired as fast as possible.

### Technology

#### As technologies i want to use: 
#### `Oracle Cloud Infrastructure` - processing
#### `Python Scripting` - data manipulation.

### `Third Component` 
( _HR employee input_ )

### Introduction.
In this component HR employee can see the students and their needs about technologies and stuff about their employees.
### Technology

#### As technologies i want to use: 
#### `Docker` - all component under one roof.
#### `Java & Spring Boot` - for backend.
#### `Javascript & React` - for frontend.
#### `MongoDb` - student cv as json.
#### `PostgresDb` - processing jsons.
#### `Cronjob` - sql jobs programming
#### `Python ETL Scripting` - jobs creations
#### `RabbitMQ` - jsons manip.
#### `MongoDb Change Streams` - json manip.



