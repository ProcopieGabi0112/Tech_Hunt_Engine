1. Move wallet to a safe location.
2. Import connection to SQL Developer
3. Password is 12345
4. Set wallet location for all connections